<?php 



/*



 * Write here your options



 */



$options = array( 



	



	/*** General Setting ***/



	



    array(



        "type" => "section",



        "icon" => "acera-icon-home",



        "title" => "General Settings",



        "id" => "general",



        "expanded" => "true"



    ),



	



		/*** Header Setting ***/



	



		array(



			"section" => "general",



			"type" => "heading",



			"title" => "Header Setting",



			"id" => "header-setting"



		),



		



			array(



				"under_section" => "header-setting", //Required



				"type" => "image", //Required



				"placeholder" => "Upload Logo",



				"display_checkbox_id" => "toggle_checkbox_id",



				"name" => "Logo", //Required



				"id" => "bgf_logo", //Required



				"desc" => "Please upload logo here.",



				"default" => ""



			),



			



			array(



				"under_section" => "header-setting", //Required



				"type" => "image", //Required



				"placeholder" => "Tage Line",



				"display_checkbox_id" => "toggle_checkbox_id",



				"name" => "Tag Line", //Required



				"id" => "bgf_tag_logo", //Required



				"desc" => "Please upload tag line image here.",



				"default" => ""



			),



			



			array(



				"under_section" => "header-setting", //Required



				"type" => "image", //Required



				"placeholder" => "Upload Favicon",



				"display_checkbox_id" => "toggle_checkbox_id",



				"name" => "Favicon", //Required



				"id" => "bgf_favicon", //Required



				"desc" => "Please upload favicon here.",



				"default" => ""



			),



			



			array(



				"under_section" => "header-setting", //Required



				"type" => "text", //Required



				"placeholder" => "Banner text",



				"display_checkbox_id" => "toggle_checkbox_id",



				"name" => "Banner text", //Required



				"id" => "bgf_banenr_text", //Required



				"desc" => "Please add banner text here.",



				"default" => ""



			),



			



			



		/*** End Header Setting ***/



		



		/*** Social Media Setting ***/



		



		array(



			"section" => "general",



			"type" => "heading",



			"title" => "Social Media",



			"id" => "social-setting"



		),











			array(



				"under_section" => "social-setting",



				"type" => "text",



				"name" => "Facebook",



				"id" => "bgf_facebook",



				"desc" => "Please type Facebook link here.",



				"default" => ""



			),

			





		array(



				"under_section" => "social-setting",



				"type" => "text",



				"name" => "Twitter",



				"id" => "bgf_twitter",



				"desc" => "Please type twitter link here.",



				"default" => ""



			), 		

			



		array(



				"under_section" => "social-setting",



				"type" => "text",



				"name" => "Linkedin",



				"id" => "bgf_linkedin",



				"desc" => "Please type linkedin link here.",



				"default" => ""



			),		

			

			



		array(



				"under_section" => "social-setting",



				"type" => "text",



				"name" => "GooglePlus",



				"id" => "bgf_googleplus",



				"desc" => "Please type google plus link here.",



				"default" => ""



			),



		



			



		

		



		



			



			



			



		/*** End Social Media Setting ***/



		



		/*** Footer Setting ***/



		



		array(



			"section" => "general",



			"type" => "heading",



			"title" => "Footer Setting",



			"id" => "footer-setting"



		),



		



			array(



				"under_section" => "footer-setting",



				"type" => "textarea",



				"name" => "Content",



				"id" => "bgf_footer_copy",



				"desc" => "Please type Content here.",



				"default" => ""



			),



			



				array(



				"under_section" => "footer-setting",



				"type" => "text",



				"name" => "Copyright",



				"id" => "bgf_copyright",



				"desc" => "Please type copyright text here.",



				"default" => ""



			),



			



				array(



				"under_section" => "footer-setting", //Required



				"type" => "image", //Required



				"placeholder" => "Upload Footer Logo",



				"display_checkbox_id" => "toggle_checkbox_id",



				"name" => "Footer Logo", //Required



				"id" => "bgf_footer_logo", //Required



				"desc" => "Please upload footer logo here.",



				"default" => ""



			),



		



		



		/*** End Footer Setting ***/



	



		/*** Start Popup Setting ***/



	



	array(



		"section" => "general",



		"type" => "heading",



		"title" => "Popup Setting",



		"id" => "popup-setting"



	),



		



		array(



				"under_section" => "popup-setting", //Required



				"type" => "image", //Required



				"placeholder" => "Upload Image",



				"display_checkbox_id" => "toggle_checkbox_id",



				"name" => "Upload Popup Image", //Required



				"id" => "bgf_popup_image", //Required



				"desc" => "Please upload popup image.",



				"default" => ""



			),



	



	/*** End Popup Setting ***/



	



	/*** Start Home Setting ***/



	



	array(



        "type" => "section",



        "icon" => "acera-icon-home",



        "title" => "Home Settings",



        "id" => "home",



        "expanded" => "true"



    ),



	



	/*** Home Page Setting ***/



		



		array(



			"section" => "home",



			"type" => "heading",



			"title" => "Setting",



			"id" => "home-setting"



		),



		



			array(



				"under_section" => "home-setting",



				"type" => "text",



				"name" => "Title",



				"id" => "bgf_home_title",



				"desc" => "Please type title here.",



				"default" => ""



			),



			



			array(



				"under_section" => "home-setting",



				"type" => "textarea",



				"name" => "Content",



				"id" => "bgf_home_content",



				"desc" => "Please type content here.",



				"default" => ""



			),



			



			array(



				"under_section" => "home-setting",



				"type" => "text",



				"name" => "Video Link",



				"id" => "bgf_home_video_link",



				"desc" => "Please type video link here.",



				"default" => ""



			),



			



			array(



				"under_section" => "home-setting", //Required



				"type" => "image", //Required



				"placeholder" => "Upload Image",



				"display_checkbox_id" => "toggle_checkbox_id",



				"name" => "Upload video thumb Image", //Required



				"id" => "bgf_video_thumb_image", //Required



				"desc" => "Please upload video thumb image.",



				"default" => ""



			),



	/*** End Home Setting ***/



	



	/*** Start Contact Setting ***/



	



	array(



        "type" => "section",



        "icon" => "acera-icon-home",



        "title" => "Contact Settings",



        "id" => "contactus",



        "expanded" => "true"



    ),



	



		/*** Contact Page Setting ***/



		



		array(



			"section" => "contactus",



			"type" => "heading",



			"title" => "Setting",



			"id" => "contect-setting"



		),



			array(



				"under_section" => "contect-setting",



				"type" => "textarea",



				"name" => "Google Map",



				"id" => "bgf_googlemap_content",



				"desc" => "Please type contact no here.",



				"default" => ""



			),





			array(



				"under_section" => "contect-setting",



				"type" => "text",



				"name" => "Phone No",



				"id" => "bgf_contact_phone",



				"desc" => "Please type phone no here.",



				"default" => ""



			),





			array(



				"under_section" => "contect-setting",



				"type" => "text",



				"name" => "Email",



				"id" => "bgf_contact_email",



				"desc" => "Please type email here.",



				"default" => ""



			),



			



			array(



				"under_section" => "contect-setting",



				"type" => "text",



				"name" => "Address",



				"id" => "bgf_header_address",



				"desc" => "Please enter address here.",



				"default" => ""



			),



			



		/*				



			array(



				"under_section" => "contect-setting",



				"type" => "textarea",



				"name" => "Address",



				"id" => "bgf_contact_address",



				"desc" => "Please type address here.",



				"default" => ""



			),



		*/	



		/*** End Contact Setting ***/



);



?>