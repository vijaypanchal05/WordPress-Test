<?php
/**
 * @package WordPress
 * @subpackage Traveler
 * @since 1.0
 *
 * Hotel loop room none
 *
 * Created by ShineTheme
 *
 */
?>
<div class="alert alert-danger">
    <p><?php st_the_language('no_room_found')?></p>
</div>