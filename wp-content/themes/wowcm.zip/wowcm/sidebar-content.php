<?php



/**



 * The sidebar containing the main widget area



 *



 * @package WordPress



 * @subpackage Twenty_Fifteen



 * @since Twenty Fifteen 1.0



 */



?>



<div class="content-left">



           <div class="sidebarblock bdrbtm">

           <ul class="sidebar-nav">
		  <?php $parent_title = get_the_title($post->post_parent);?>
           <h2><?php echo $parent_title; ?></h2>

            <?php if(is_active_sidebar( 'sidebar_link' )):

				dynamic_sidebar('sidebar_link');

				endif; ?> 

           </ul>       

           </div>



           <div class="sidebarblock">



                 <ul class="sidebar-cta">



                    <li><h2>book a party</h2>



              <?php if(is_active_sidebar( 'book_party' )):



				dynamic_sidebar('book_party');



				endif; ?>   

               



                    </li>



                    <li><h2>become a member</h2>



                <?php if(is_active_sidebar( 'become_member' )):



				dynamic_sidebar('become_member');



				endif; ?>

                <a class="btn-orange" href="<?php bloginfo('url'); ?>/become-a-member/">Join Today</a>



                    </li>



                    <li><h2>donate today</h2>



                       <?php if(is_active_sidebar( 'donate_today' )):



				dynamic_sidebar('donate_today');



				endif; ?>
                    </li>



                </ul>



           </div>



         



           </div>