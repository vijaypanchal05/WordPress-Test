<?php
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<!--[if lt IE 9]>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/html5.js"></script>
	<![endif]-->
    
<!-- Main Style -->
<link rel="stylesheet" href="<?php echo get_bloginfo('stylesheet_directory');?>/css/style.css">

<link rel="stylesheet" href="<?php echo get_bloginfo('stylesheet_directory');?>/css/custom.css">


<!-- Google Fonts -->
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700|Hind:400,300,500,600,700' rel='stylesheet' type='text/css'>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<?php wp_head(); ?>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-44006715-1', 'auto');
  ga('send', 'pageview');
</script>
</head>
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
var js, fjs = d.getElementsByTagName(s)[0];
if (d.getElementById(id)) return;
js = d.createElement(s); js.id = id;
js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5";
fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebookjssdk'))
;</script>
<!-- Pre-loader -->
<div class="preloader">
	<div class="status">&nbsp;</div>
</div>

<header id="header" class="sticky">
       <div class="header">
       	<div class="container clearfix">
			<div class="logo">
				<a href="<?php echo get_site_url();?>">
		<img alt="WOW Children&#039;s Museum" title="WOW Children&#039;s Museum" src="<?php echo get_option('bgf_logo');?>"> 
            </a>
			</div>
            <div class="donate-header">
            <a href="https://68348.blackbaudhosting.com/68348/Individuals--General-Operating" target="_blank" class="btn-green">Donate Today</a>
				<?php /*?><?php if(is_active_sidebar( 'donate_button' )):
    	        dynamic_sidebar('donate_button');
        	    endif; ?><?php */?>
                <img class="pirate_kid" src="<?php echo get_bloginfo('stylesheet_directory');?>/images/pirate_kid.svg" alt="">
            </div>
            <div class="top-menu">
            <?php wp_nav_menu( array('theme_location' => 'header_main','menu_class'=> '','container'=>''));?>
            </div>
            
    <nav class="navigation">
 	<?php wp_nav_menu( array('theme_location' => 'primary','menu_class'=> '','container'=>''));?>     </nav> 
       </div>
  </div>
  </header>
<div class="clearfix"></div>





