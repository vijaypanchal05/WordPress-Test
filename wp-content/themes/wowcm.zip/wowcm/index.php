<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * e.g., it puts together the home page when no home.php file exists.
 *
 * Learn more: {@link https://codex.wordpress.org/Template_Hierarchy}
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); ?>

<section class="sections">
    <div class="container">
        <div class="wcm-rsidebar">
        <div class="dr-line-in"></div>
        <div class="content-left">
            <h1>WOW! Blog</h1>
            <div class="blog-post-listing">

       <?php if ( have_posts() ) : 
		while ( have_posts() ) : the_post();
		$getpostid =  get_the_ID();
		$imageSourcepost=wp_get_attachment_image_src(get_post_thumbnail_id($getpostid),"large");
		$category = get_the_category();
		$category_id = get_cat_ID($category[0]->cat_name);
	    $category_link = get_category_link( $category_id );?>                
<div class="blog-post">
<?php  if($imageSourcepost[0]!=''){?>    
<img alt="<?php the_title();?>" src="<?php echo $imageSourcepost[0];?>">
<?php }else { ?>    
<img alt="<?php the_title();?>" src="<?php echo get_site_url();?>/wp-content/uploads/2016/03/logo.png">
<?php } ?>

<div class="blog-cont">
<h2><a href="<?php echo get_permalink();?>"><?php the_title();?></a></h2>
<div class="dateCategory">Posted on <?php the_time('F j, Y');?> | <a href="#"> <?php echo get_the_author();?> </a></div>
<p><?php echo excerpt(37);?></p>
<a href="<?php echo get_permalink();?>" class="btn-endeavour">Continue Reading</a>
                            </div>
                        </div>
                
<?php endwhile; wp_reset_query(); ?>
        	<div class="wp-pagenavi  clearfix blog-nxt-prv">
            <?php if(function_exists('wp_paginate')) {wp_paginate();}?>
            </div>
            <?php  endif;?>
                
</div>
           
                <!--<div class="wp-pagenavi">
                   <a href="#" class="first">« Previous</a>
                   <span class="current">1</span>
                   <a href="#" class="page smaller">2</a>
                   <a href="#" class="page smaller">3</a>
                   <a href="#" class="page smaller">4</a>
                   <a href="#" class="page smaller">5</a>
                   <span class="extend">....</span>
                   <a href="#" class="page smaller">9</a>
                   <a href="#" class="page smaller">10</a>
                   <a href="#" class="last">Next »</a>
                </div>-->
            
        </div>
        
<div class="content-right">
<?php get_sidebar();?>    
    

</div>
            
    </div>
  </div>
</section>
      
 
	
<?php get_footer(); ?>
