<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); ?>

      
<section class="sections">
    <div class="container">
        <div class="wcm-rsidebar">
        <div class="dr-line-in"></div>
        <div class="content-left">
            
      <?php if ( have_posts() ) : 
		while ( have_posts() ) : the_post();
		$getpostid =  get_the_ID();
		$imageSourcepost=wp_get_attachment_image_src(get_post_thumbnail_id($getpostid),"large");
		$category = get_the_category();
		$category_id = get_cat_ID($category[0]->cat_name);
	    $category_link = get_category_link( $category_id );?>
    
            
            
<article class="blogarticle">
<h1><?php the_title();?></h1>
<div class="dateCategory">Posted on <?php the_time('F j, Y');?> | <a href="#"> <?php echo get_the_author();?> </a></div>
    
<?php /*?><?php if($imageSourcepost[0]!=''){?>    
<img src="images/blo_post.jpg" alt="">
<?php } ?> <?php */?>   
<p><?php the_content();?></p>
                
</article>

                            
    <div class="tags"><strong>Tags:</strong> 
        
<?php
$posttags = get_the_tags();
if ($posttags) {
foreach($posttags as $tag) {
echo $tag->name . ','; 
}
}
?>    
                    
                </div>
            
    <div class="blog_social_icons">
    <?php echo do_shortcode('[addtoany]');?>
                    <!--<ul>
                        <li class="buffer"><a target="_blank" href="#1">
                        <i class="fa fa-buffer"></i>Buffer</a></li>
                        <li class="facebook"><a target="_blank" href="1#">
                        <i class="fa fa-facebook"></i>Facebook</a></li>
                        <li class="twitter"><a target="_blank" href="#1">
                        <i class="fa fa-twitter"></i>Twitter</a></li>
                        <li class="emailprint"><a target="_blank" href="#1">
                        <i class="fa fa-envelope"></i>Email</a></li>
                        <li class="more"><a target="_blank" href="#1">
                        <i class="fa fa-plus"></i>More</a></li>
                    </ul>-->
                </div>

<div class="leave-comment">
            <?php
   	//If comments are open or we have at least one comment, load up the comment template.
	if(comments_open() || get_comments_number() ) :
	comments_template();
	endif;?>
          </div>
                     
<?php endwhile; wp_reset_query(); ?>
<?php  endif;?>
            </div>
        
    <div class="content-right">
        <?php get_sidebar();?>    
    </div>
  </div>
   </div>
</section>
      
<?php get_footer(); ?>
