<section class="sections">

      <div class="container line-top">

          <div class="sections-title">

           <?php echo do_shortcode('[acf field="explore_our_website"]');?>

        </div>

        <div class="exhibitsList">

            <div class="block">

                <h2><i class="icon-noun_14283"></i> visit the exhibits </h2>

                <div class="box-pad">

                <?php if(is_active_sidebar( 'visit_the_exhibits' )):

				dynamic_sidebar('visit_the_exhibits');

				endif; ?>  

                </div>

            </div>

            <div class="block">

                <h2><i class="icon-noun_106841"></i> view our calendar </h2>

                <div class="box-pad">

                    <?php if(is_active_sidebar( 'view_our_calendar' )):

						dynamic_sidebar('view_our_calendar');

					endif; ?>  

                </div>

            </div>

            <div class="block">

                <h2><i class="icon-noun_4060"></i> become a member </h2>

                <div class="box-pad">

                    <?php if(is_active_sidebar( 'become_member' )):

				dynamic_sidebar('become_member');

				endif; ?>
			 <a href="<?php echo get_site_url();?>/become-a-member/" class="btn-orange">Join Today</a>
                </div>

            </div> 

            

        </div>

    </div>

</section>

  

