<?php
/**
 * The sidebar containing the main widget area
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
?>

 
<div class="sidebarblock bdrbtm">
<h2>categories</h2>
<ul class="sidebar-nav">
<?php 
    $args = array(
	'show_option_all'    => '',
	'orderby'            => 'name',
	'order'              => 'ASC',
	'style'              => 'list',
	'show_count'         => 0,
	'hide_empty'         => 1,
	'use_desc_for_title' => 1,
	'child_of'           => 0,
	'feed'               => '',
	'feed_type'          => '',
	'feed_image'         => '',
	'exclude'            => '',
	'exclude_tree'       => '',
	'include'            => '',
	'hierarchical'       => 1,
	'title_li'           => __( '' ),
	'show_option_none'   => __( '' ),
	'number'             => null,
	'echo'               => 1,
	'depth'              => 0,
	'current_category'   => 0,
	'pad_counts'         => 0,
	'taxonomy'           => 'category',
	'walker'             => null
    );wp_list_categories( $args );?>
                        </ul>   
                </div>
               
<div class="sidebarblock bdrbtm">
<button type="button" class="btn btn-primary btn-grape full" data-toggle="modal" data-target=".bs-example-modal-sm">Sign up for our Newsletter</button>
</div>

<div class="sidebarblock">
    
<ul class="sidebar-cta">
<li><h2>book a party</h2>
<?php if(is_active_sidebar( 'book_party' )):
dynamic_sidebar('book_party');
endif; ?>
</li>

<li><h2>become a member</h2>
<?php if(is_active_sidebar( 'become_member' )):
dynamic_sidebar('become_member');
endif; ?>
<a class="btn-orange" href="#">Get Started</a>
</li>
<li><h2>donate today</h2>
         <?php if(is_active_sidebar( 'donate_today' )):
dynamic_sidebar('donate_today');
endif; ?>
                    </li>
</ul>
           </div>
