<?php

/**

 * The template for displaying pages

 *

 * This is the template that displays all pages by default.

 * Please note that this is the WordPress construct of pages and that

 * other "pages" on your WordPress site will use a different template.

 *

 * @package WordPress

 * @subpackage Twenty_Fifteen

 * @since Twenty Fifteen 1.0

 */

get_header(); ?>

<section class="sections">

    <div class="container">

        <div class="content-holder">

        <div class="dr-line-in"></div>

        <?php get_sidebar('content');?>

        <div class="content-right">
			<h1><?php the_title();?></h1>
         <?php
          while ( have_posts() ) : the_post();
		//  echo $post->post_content;
			the_content();
		  endwhile; ?>

        </div>

    </div>

  </div>

</section>



<?php get_footer(); ?>

