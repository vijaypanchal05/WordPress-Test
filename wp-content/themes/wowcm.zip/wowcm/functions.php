<?php

//

// Recommended way to include parent theme styles.

//  (Please see http://codex.wordpress.org/Child_Themes#How_to_Create_a_Child_Theme)

//  



//

// Your code goes below

//

include_once 'options/options-init.php';



function replace_howdy( $wp_admin_bar ) {

 $my_account=$wp_admin_bar->get_node('my-account');

 $newtitle = str_replace( 'Howdy,', 'Welcome!', $my_account->title );

 $wp_admin_bar->add_node( array(

 'id' => 'my-account',

 'title' => $newtitle,

 ) );

 }

add_filter( 'admin_bar_menu', 'replace_howdy',25 );



register_sidebar( array(

'name'=> __( 'museum hours', 'twentyfifteen' ),

'id' => 'museum_hours',

'description'=>__( 'museum hours', 'twentyfifteen' ),

		'before_widget' => '',

		'after_widget'  => '',

		'before_title'  => '<span class="hide_title">',

		'after_title'   => '</span>',

	));

	

	

register_sidebar( array(

'name'=> __( 'Toddler Hours', 'twentyfifteen' ),

'id' => 'toddler_hours',

'description'=>__( 'Toddler Hours', 'twentyfifteen' ),

		'before_widget' => '',

		'after_widget'  => '',

		'before_title'  => '<span class="hide_title">',

		'after_title'   => '</span>',

	));	





register_sidebar( array(

'name'=> __( 'location footer', 'twentyfifteen' ),

'id' => 'location-footer',

'description'=>__( 'location footer', 'twentyfifteen' ),

		'before_widget' => '',

		'after_widget'  => '',

		'before_title'  => '<h3>',

		'after_title'   => '</h3>',

	));

	

	



	

	

	

register_sidebar( array(

'name'=> __( 'admission footer', 'twentyfifteen' ),

'id' => 'admission',

'description'=>__( 'admission footer', 'twentyfifteen' ),

		'before_widget' => '',

		'after_widget'  => '',

		'before_title'  => '<h3>',

		'after_title'   => '</h3>',

	));

	



register_sidebar( array(

'name'=> __( 'contact us', 'twentyfifteen' ),

'id' => 'contact-us',

'description'=>__( 'contact us', 'twentyfifteen' ),

		'before_widget' => '',

		'after_widget'  => '',

		'before_title'  => '<h3>',

		'after_title'   => '</h3>',

	));





register_sidebar( array(

'name'=> __( 'about', 'twentyfifteen' ),

'id' => 'about-us',

'description'=>__( 'about-us', 'twentyfifteen' ),

		'before_widget' => '',

		'after_widget'  => '',

		'before_title'  => '<h3>',

		'after_title'   => '</h3>',

	));





register_sidebar( array(

'name'=> __( 'resources', 'twentyfifteen' ),

'id' => 'resources',

'description'=>__( 'resources', 'twentyfifteen' ),

		'before_widget' => '',

		'after_widget'  => '',

		'before_title'  => '<h3>',

		'after_title'   => '</h3>',

	));

	

	

register_sidebar( array(

'name'=> __( 'book a party', 'twentyfifteen' ),

'id' => 'book_party',

'description'=>__( 'book a party', 'twentyfifteen' ),

		'before_widget' => '',

		'after_widget'  => '',

		'before_title'  => '<span class="hide_title">',

		'after_title'   => '</span>',

));





register_sidebar( array(

'name'=> __( 'become a member', 'twentyfifteen' ),

'id' => 'become_member',

'description'=>__( 'become a member', 'twentyfifteen' ),

		'before_widget' => '',

		'after_widget'  => '',

		'before_title'  => '<span class="hide_title">',

		'after_title'   => '</span>',

));





register_sidebar( array(

'name'=> __( 'donate today', 'twentyfifteen' ),

'id' => 'donate_today',

'description'=>__( 'donate today', 'twentyfifteen' ),

		'before_widget' => '',

		'after_widget'  => '',

		'before_title'  => '<span class="hide_title">',

		'after_title'   => '</span>',

));



	

register_sidebar( array(

'name'=> __( 'museum hours block', 'twentyfifteen' ),

'id' => 'museum_hours_content',

'description'=>__( 'museum hours block', 'twentyfifteen' ),

		'before_widget' => '',

		'after_widget'  => '',

		'before_title'  => '<span class="hide_title">',

		'after_title'   => '</span>',

));



register_sidebar( array(

'name'=> __( 'admission block', 'twentyfifteen' ),

'id' => 'admission_content',

'description'=>__( 'admission block', 'twentyfifteen' ),

		'before_widget' => '',

		'after_widget'  => '',

		'before_title'  => '<span class="hide_title">',

		'after_title'   => '</span>',

));







register_sidebar( array(

'name'=> __( 'location block', 'twentyfifteen' ),

'id' => 'location_content',

'description'=>__( 'location block', 'twentyfifteen' ),

		'before_widget' => '',

		'after_widget'  => '',

		'before_title'  => '<span class="hide_title">',

		'after_title'   => '</span>',

));





register_sidebar( array(

'name'=> __( 'schedule a field trip', 'twentyfifteen' ),

'id' => 'field_trip',

'description'=>__( 'schedule a field trip', 'twentyfifteen' ),

		'before_widget' => '',

		'after_widget'  => '',

		'before_title'  => '<span class="hide_title">',

		'after_title'   => '</span>',

));



register_sidebar( array(

'name'=> __( 'rent a room', 'twentyfifteen' ),

'id' => 'rent_room',

'description'=>__( 'rent a room', 'twentyfifteen' ),

		'before_widget' => '',

		'after_widget'  => '',

		'before_title'  => '<span class="hide_title">',

		'after_title'   => '</span>',

));





register_sidebar( array(

'name'=> __( 'visit the exhibits', 'twentyfifteen' ),

'id' => 'visit_the_exhibits',

'description'=>__( 'visit the exhibits', 'twentyfifteen' ),

		'before_widget' => '',

		'after_widget'  => '',

		'before_title'  => '<span class="hide_title">',

		'after_title'   => '</span>',

));



register_sidebar( array(

'name'=> __( 'view our calendar', 'twentyfifteen' ),

'id' => 'view_our_calendar',

'description'=>__( 'view our calendar', 'twentyfifteen' ),

		'before_widget' => '',

		'after_widget'  => '',

		'before_title'  => '<span class="hide_title">',

		'after_title'   => '</span>',

));


register_sidebar( array(

'name'=> __( 'upcoming events', 'twentyfifteen' ),

'id' => 'upcoming_events',

'description'=>__( 'upcoming events', 'twentyfifteen' ),

		'before_widget' => '',

		'after_widget'  => '',

		'before_title'  => '<h2>',

		'after_title'   => '</h2>',

));








register_sidebar( array(

'name'=> __( 'annual events', 'twentyfifteen' ),

'id' => 'annual_events',

'description'=>__( 'annual events', 'twentyfifteen' ),

		'before_widget' => '',

		'after_widget'  => '',

		'before_title'  => '<h2>',

		'after_title'   => '</h2>',

));



register_sidebar( array(
'name'=> __( 'Upcoming Exhibits', 'twentyfifteen' ),
'id' => 'upcoming_exhibits',
'description'=>__( 'Upcoming Exhibits', 'twentyfifteen' ),
		'before_widget' => '',
		'after_widget'  => '',
		'before_title'  => '<h2>',
		'after_title'   => '</h2>',
));




register_sidebar( array(
'name'=> __( 'Left Sidebar', 'twentyfifteen' ),
'id' => 'left_sidebar',
'description'=>__( 'Left Sidebar', 'twentyfifteen' ),
		'before_widget' => '',
		'after_widget'  => '',
		'before_title'  => '<h2>',
		'after_title'   => '</h2>',
));


register_sidebar( array(
'name'=> __( 'What’s nearby', 'twentyfifteen' ),
'id' => 'whats_nearby',
'description'=>__( 'What’s nearby', 'twentyfifteen' ),
		'before_widget' => '',
		'after_widget'  => '',
		'before_title'  => '<h2>',
		'after_title'   => '</h2>',
));


register_sidebar( array(
'name'=> __( 'Cleaning Procedures', 'twentyfifteen' ),
'id' => 'cleaning_procedures',
'description'=>__( 'Cleaning Procedures', 'twentyfifteen' ),
		'before_widget' => '',
		'after_widget'  => '',
		'before_title'  => '<h2>',
		'after_title'   => '</h2>',
));



register_sidebar( array(
'name'=> __( 'Sidebar Link', 'twentyfifteen' ),
'id' => 'sidebar_link',
'description'=>__( 'Sidebar Link', 'twentyfifteen' ),
		'before_widget' => '',
		'after_widget'  => '',
		'before_title'  => '<span class="hide_title">',
		'after_title'   => '</span>',
));

register_sidebar( array(
'name'=> __( 'Donate Button', 'twentyfifteen' ),
'id' => 'donate_button',
'description'=>__( 'Donate Button', 'twentyfifteen' ),
		'before_widget' => '',
		'after_widget'  => '',
		'before_title'  => '<span class="hide_title">',
		'after_title'   => '</span>',
));




function excerpt($limit) {

  $excerpt = explode(' ', get_the_excerpt(), $limit);

  if (count($excerpt)>=$limit) {

    array_pop($excerpt);

    $excerpt = implode(" ",$excerpt).'...';

  } else {

    $excerpt = implode(" ",$excerpt);

  }	

  $excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);

  return $excerpt;

}

if (function_exists('register_nav_menus')){
        register_nav_menu('header_main', 'Top Menu' );
        register_nav_menu('visit_menu','Visit Menu' );
	    register_nav_menu('about_menu','About Menu' );
	    register_nav_menu('exhibits_menu','Exhibits Menu' );
    }
	

// contact info
add_action('init', 'contact_info');
function contact_info() {

	$labels = array(

		'name' =>_x('Contact Info', 'post type general name'),

		'singular_name' =>_x('Contact Info', 'post type singular name'),

		'add_new' =>_x('Add New', 'Contact Info'),

		'add_new_item' => __('Add New'),

		'edit_item' =>__('Edit Item'),

		'new_item' =>__('New Item'),

		'view_item' =>__('View Item'),

		'search_items'=>__('Search'),

		'not_found' =>__('Nothing found'),

		'not_found_in_trash'=>__('Nothing found in Trash'),

		'parent_item_colon'=>''

	);

	$args = array(

		'labels' => $labels,

		'public' => true,

		'publicly_queryable' => true,

		'show_ui' => true,

		'query_var' => true,

		'rewrite' => true,

		'capability_type' => 'post',

		'hierarchical' => false,

		'supports' => array('title','editor','thumbnail'),

	  ); 

//pti_set_post_type_icon('contact_info','gear');	 

register_post_type( 'contact_info' , $args );
}
// contact info





// get involved
add_action('init', 'get_involved');
function get_involved() {

	$labels = array(

		'name' =>_x('Get Involved', 'post type general name'),

		'singular_name' =>_x('Get Involved', 'post type singular name'),

		'add_new' =>_x('Add New', 'Get Involved'),

		'add_new_item' => __('Add New'),

		'edit_item' =>__('Edit Item'),

		'new_item' =>__('New Item'),

		'view_item' =>__('View Item'),

		'search_items'=>__('Search'),

		'not_found' =>__('Nothing found'),

		'not_found_in_trash'=>__('Nothing found in Trash'),

		'parent_item_colon'=>''

	);

	$args = array(

		'labels' => $labels,

		'public' => true,

		'publicly_queryable' => true,

		'show_ui' => true,

		'query_var' => true,

		'rewrite' => true,

		'capability_type' => 'post',

		'hierarchical' => false,

		'supports' => array('title','editor','thumbnail'),

	  ); 

register_post_type( 'get_involved' , $args );
}
//get involved

//exhibits
add_action('init', 'exhibits');
function exhibits() {

	$labels = array(

		'name' =>_x('exhibits', 'post type general name'),

		'singular_name' =>_x('exhibits', 'post type singular name'),

		'add_new' =>_x('Add New', 'exhibits'),

		'add_new_item' => __('Add New'),

		'edit_item' =>__('Edit Item'),

		'new_item' =>__('New Item'),

		'view_item' =>__('View Item'),

		'search_items'=>__('Search'),

		'not_found' =>__('Nothing found'),

		'not_found_in_trash'=>__('Nothing found in Trash'),

		'parent_item_colon'=>''

	);

	$args = array(

		'labels' => $labels,

		'public' => true,

		'publicly_queryable' => false,

		'show_ui' => true,

		'query_var' => true,

		'rewrite' => true,

		'capability_type' => 'post',

		'hierarchical' => false,

		'supports' => array('title','editor','thumbnail'),

	  ); 

register_post_type( 'exhibits' , $args );}
//exhibits


//fieldtrip
add_action('init', 'fieldtrip');
function fieldtrip() {
	$labels = array(
		'name' =>_x('fieldtrip', 'post type general name'),
		'singular_name' =>_x('fieldtrip', 'post type singular name'),
		'add_new' =>_x('Add New', 'fieldtrip'),
		'add_new_item' => __('Add New'),
		'edit_item' =>__('Edit Item'),
		'new_item' =>__('New Item'),
		'view_item' =>__('View Item'),
		'search_items'=>__('Search'),
		'not_found' =>__('Nothing found'),
		'not_found_in_trash'=>__('Nothing found in Trash'),
		'parent_item_colon'=>''
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'publicly_queryable' => false,
		'show_ui' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'supports' => array('title','editor','thumbnail'),
	  ); 
register_post_type( 'fieldtrip' , $args );}
//fieldtrip




//parties
add_action('init', 'partie');
function partie() {
	$labels = array(
		'name' =>_x('parties', 'post type general name'),
		'singular_name' =>_x('parties', 'post type singular name'),
		'add_new' =>_x('Add New', 'parties'),
		'add_new_item' => __('Add New'),
		'edit_item' =>__('Edit Item'),
		'new_item' =>__('New Item'),
		'view_item' =>__('View Item'),
		'search_items'=>__('Search'),
		'not_found' =>__('Nothing found'),
		'not_found_in_trash'=>__('Nothing found in Trash'),
		'parent_item_colon'=>''
	);
	$args = array(
		'labels' => $labels,
		'public' => false,
		'publicly_queryable' => false,
		'show_ui' => true,
		'query_var' => true,
		'rewrite' => false,
		'capability_type' => 'post',
		'hierarchical' => false,
		'supports' => array('title','editor','thumbnail'),
	  ); 
register_post_type( 'partie' , $args );}
//parties



	//fieldtrip
add_action('init', 'classes');
function classes() {
	$labels = array(
		'name' =>_x('Programs & Classes Overview', 'post type general name'),
		'singular_name' =>_x('classes', 'post type singular name'),
		'add_new' =>_x('Add New', 'classes'),
		'add_new_item' => __('Add New'),
		'edit_item' =>__('Edit Item'),
		'new_item' =>__('New Item'),
		'view_item' =>__('View Item'),
		'search_items'=>__('Search'),
		'not_found' =>__('Nothing found'),
		'not_found_in_trash'=>__('Nothing found in Trash'),
		'parent_item_colon'=>''
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'publicly_queryable' => false,
		'show_ui' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'supports' => array('title','editor','thumbnail'),
	  ); 
register_post_type( 'classes' , $args );}
//fieldtrip




//events
add_action('init', 'events');
function events() {
	$labels = array(
		'name' =>_x('events', 'post type general name'),
		'singular_name' =>_x('events', 'post type singular name'),
		'add_new' =>_x('Add New', 'events'),
		'add_new_item' => __('Add New'),
		'edit_item' =>__('Edit Item'),
		'new_item' =>__('New Item'),
		'view_item' =>__('View Item'),
		'search_items'=>__('Search'),
		'not_found' =>__('Nothing found'),
		'not_found_in_trash'=>__('Nothing found in Trash'),
		'parent_item_colon'=>''
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'publicly_queryable' => false,
		'show_ui' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'supports' => array('title','editor','thumbnail'),
	  ); 
register_post_type( 'events' , $args );}
//event




    /*WordPress Menus API.*/
    function add_new_menu_items()
    {
        //add a new menu item. This is a top level menu item i.e., this menu item can have sub menus
        add_menu_page(
            "Theme Options", //Required. Text in browser title bar when the page associated with this menu item is displayed.
            "Theme Options", //Required. Text to be displayed in the menu.
            "manage_options", //Required. The required capability of users to access this menu item.
            "theme-options", //Required. A unique identifier to identify this menu item.
            "theme_options_page", //Optional. This callback outputs the content of the page associated with this menu item.
            "", //Optional. The URL to the menu item icon.
            100 //Optional. Position of the menu item in the menu.
        );

    }

    function theme_options_page()
    {
        ?>
            <div class="wrap">
            <div id="icon-options-general" class="icon32"></div>
            <h1>Theme Options</h1>
            <form method="post" action="options.php">
                <?php
               
                    //add_settings_section callback is displayed here. For every new section we need to call settings_fields.
                    settings_fields("header_section");
                   
                    // all the add_settings_field callbacks is displayed here
                    do_settings_sections("theme-options");
               
                    // Add the submit button to serialize the options
                    submit_button();
                   
                ?>         
            </form>
        </div>
        <?php
    }

    //this action callback is triggered when wordpress is ready to add new items to menu.
    add_action("admin_menu", "add_new_menu_items");


    /*WordPress Settings API Demo*/

    function display_options()
    {
        //section name, display name, callback to print description of section, page to which section is attached.
        add_settings_section("header_section", "Header Options", "display_header_options_content", "theme-options");

        //setting name, display name, callback to print form element, page in which field is displayed, section to which it belongs.
        //last field section is optional.
        add_settings_field("header_logo", "Logo Url", "display_logo_form_element", "theme-options", "header_section");
        add_settings_field("advertising_code", "Ads Code", "display_ads_form_element", "theme-options", "header_section");
        
        add_settings_field("advertising_code_new", "Ads Code1", "display_ads_form_element1", "theme-options", "header_section");
        

        //section name, form element name, callback for sanitization
        register_setting("header_section", "header_logo");
        register_setting("header_section", "advertising_code");
        register_setting("header_section", "advertising_code1");
    }

    function display_header_options_content(){echo "The header of the theme";}
    function display_logo_form_element()
    {
        //id and name of form element should be same as the setting name.
        ?>
            <input type="text" name="header_logo" id="header_logo" value="<?php echo get_option('header_logo'); ?>" />
        <?php
    }
    function display_ads_form_element()
    {
        //id and name of form element should be same as the setting name.
        ?>
<?php

//wp_editor(get_option('advertising_code'), 'editor', $args );
  
$settings = array( 'media_buttons' => true );

wp_editor( get_option('advertising_code'), 'advertising_code', $settings );        
        
    }




 function display_ads_form_element1()
    {
        //id and name of form element should be same as the setting name.
        ?>
<?php

//wp_editor(get_option('advertising_code'), 'editor', $args );
  
$settings = array( 'media_buttons' => true );

wp_editor( get_option('advertising_code1'), 'advertising_code1', $settings );        
        
    }



    //this action is executed after loads its core, after registering all actions, finds out what page to execute and before producing the actual output(before calling any action callback)
    add_action("admin_init", "display_options");
