<?php



/**



 * The template for displaying the footer



 *



 * Contains the closing of the "site-content" div and all content after.



 *



 * @package WordPress



 * @subpackage Twenty_Fifteen



 * @since Twenty Fifteen 1.0



 */



?>



<footer id="footer">



    <div class="footertop">



        <div class="container">



            <div class="row">



                <div class="social_share">

                    <div class="dr-line"></div>

                    <div class="row">

<div class="col-md-10">Stay connected. Follow WOW! on Facebook today!</div>

<div class="col-md-2">

<a href="https://www.facebook.com/wowchildrensmuseum.org/" target="_BLANK"><img src="http://staging.bkmtest.com/wowcm/wp-content/uploads/2016/04/facebook_button-1.png"/></a></div>



                       

                     </div>



                        



                </div>



            </div>



        </div>



    </div>



    <div class="footerbottom">



        <div class="container pr">



            <div class="island"><img class="" src="<?php echo get_bloginfo('stylesheet_directory');?>/images/island.svg" alt=""></div>



            <div class="footerblocks">



                <div class="block">



                    <div class="separator">



                    <h3>museum hours</h3>



					<?php if(is_active_sidebar( 'museum_hours' )):



                    dynamic_sidebar('museum_hours');endif; ?>



                    



                    <?php if(is_active_sidebar( 'toddler_hours' )):



                    dynamic_sidebar('toddler_hours');endif; ?>



                    </div>



                    



                    <div class="separator lc_footer">



				    <?php if(is_active_sidebar( 'location-footer' )):



					dynamic_sidebar('location-footer');



					endif; ?>



                    </div>



                </div>



                <div class="block">



                    <div class="separator">



<?php if(is_active_sidebar( 'admission' )):



dynamic_sidebar('admission');



endif; ?>



                    </div>



                    <div class="separator">



<?php if(is_active_sidebar( 'contact-us' )):



dynamic_sidebar('contact-us');



endif; ?>
<button type="button" class="btn btn-primary btn-orange small" data-toggle="modal" data-target=".bs-example-modal-sm">Sign up for our Newsletter</button>




<div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      	<div class="modal-header">
        	<button aria-label="Close" data-dismiss="modal" class="close" type="button">
        	<span aria-hidden="true">×</span></button>
        	<h2 id="mySmallModalLabel" class="modal-title blue">Sign Up Today!</h2>
        </div>
        
        <div class="modal-body">
<form style="color:#404345;" class="" method="post" action="http://oi.vresp.com?fid=833434869d" target="vr_optin_popup"
onsubmit="window.open( 'http://www.verticalresponse.com', 'vr_optin_popup',
'scrollbars=yes,width=600,height=450' ); return true;" >
<div>
<p style="margin-bottom:15px;">Get the latest news and event updates when you sign up today!</p>
<label style="font-weight:bold;">Email*</label>
<input type="email" id="email" name="email_address" class="form-control" placeholder="Email" required>
<button class="btn-submit btn-orange" type="submit" name="submit" value="Sign Up!">Sign Up!</button>
</div>
</form>
        </div>
        
    </div>
  </div>
</div>


                    </div>    



                </div>



                



                <div class="block">



                    <div class="separator">



<?php if(is_active_sidebar( 'about-us' )):



dynamic_sidebar('about-us');






endif; ?>







                    </div>



                    <div class="separator">



                        



<?php if(is_active_sidebar( 'resources' )):



dynamic_sidebar('resources');



endif; ?>



                        



                  



                    </div>



                </div>



                



                <div class="block">



<a href="http://www.cityoflafayette.com" target="_blank"><img class="footerlogo" src="<?php echo get_bloginfo('stylesheet_directory');?>/images/lafayette_logo.png" alt="lafayette"></a>

<a target="_blank" href="http://scfd.org"><img class="footerlogo" src="<?php echo get_bloginfo('stylesheet_directory');?>/images/scfd_logo.png" alt="scfd"></a>
                </div>



                



            </div>



            



            <div class="footerblocks">



<div class="copyright">



<p><?php echo get_option('bgf_copyright');?></p>



                </div>



                <div class="sunken_ship"><img src="<?php echo get_bloginfo('stylesheet_directory');?>/images/sunken_ship.png" alt=""></div>



            </div>



            



        </div>



    </div>



</footer>



<!-- End wrap -->







<div class="go-up">



<i class="fa fa-chevron-up"></i>



</div>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo get_bloginfo('stylesheet_directory');?>/js/bootstrap.min.js"></script>
    <script src="<?php echo get_bloginfo('stylesheet_directory');?>/js/jquery.sticky.js"></script>
      
    <script src="<?php echo get_bloginfo('stylesheet_directory');?>/js/owl.carousel.js"></script>
    <script>
        $("#schools-logo").owlCarousel({
        navigation: true,
        navigationText: [""],      
      });  
    </script>
      
    <!-- Custom js -->
	<script src="<?php echo get_bloginfo('stylesheet_directory');?>/js/custom.js"></script>
	<!-- End Custom js -->
      
<script type="application/javascript">jQuery("#menu-exhibits-menu" ).removeClass( "menu" ).addClass( "sidebar-nav" );</script>	


<?php if(get_the_ID()=='1744'){?>
<script type="application/javascript">
	jQuery(document).ready(function() {
 
        
    jQuery('#btn-add').click(function(){
        $('#select-from option:selected').each( function() {
				if($(this).val()!=''){
                $('#select-to').append("<option selected='selected' value='"+$(this).val()+"'>"+$(this).text()+"</option>");
 		        $(this).remove();
				}
        });
    });
    jQuery('#btn-remove').click(function(){
        $('#select-to option:selected').each( function() {
			if($(this).val()!=''){
            $('#select-from').append("<option value='"+$(this).val()+"'>"+$(this).text()+"</option>");
            $(this).remove();
			}
        });
    });
 
});

jQuery(document).ready(function() {
 
    jQuery('#btn-add1').click(function(){
		
        $('#select-from1 option:selected').each( function() {
			if($(this).val()!=''){
                $('#select-to1').append("<option selected='selected' value='"+$(this).val()+"'>"+$(this).text()+"</option>");
				$(this).remove();
						}
            
        });

    });
    jQuery('#btn-remove1').click(function(){
        $('#select-to1 option:selected').each( function() {
			if(jQuery(this).val()!=''){
            $('#select-from1').append("<option value='"+jQuery(this).val()+"'>"+$(this).text()+"</option>");
            $(this).remove();
			}
        });
    });
 
});

jQuery(document).ready(function() {
 
    jQuery('#btn-add2').click(function(){
		
        jQuery('#select-from2 option:selected').each( function() {
			if(jQuery(this).val()!=''){
                jQuery('#select-to2').append("<option selected='selected' value='"+jQuery(this).val()+"'>"+jQuery(this).text()+"</option>");
				jQuery(this).remove();
						}
            
        });

    });
    jQuery('#btn-remove2').click(function(){
        jQuery('#select-to2 option:selected').each( function() {
			if(jQuery(this).val()!=''){
            jQuery('#select-from2').append("<option value='"+jQuery(this).val()+"'>"+jQuery(this).text()+"</option>");
            jQuery(this).remove();
			}
        });
    });
 
});

jQuery(document).ready(function() {
 
    jQuery('#btn-add3').click(function(){
		
        $('#select-from3 option:selected').each( function() {
			if($(this).val()!=''){
                $('#select-to3').append("<option selected='selected' value='"+$(this).val()+"'>"+$(this).text()+"</option>");
				jQuery(this).remove();
						}
            
        });

    });
    jQuery('#btn-remove3').click(function(){
        $('#select-to3 option:selected').each( function() {
			if($(this).val()!=''){
            $('#select-from3').append("<option selected='selected' value='"+$(this).val()+"'>"+$(this).text()+"</option>");
            $(this).remove();
			}
        });
    });
 
});

</script>
<?PHP } ?>


<?php wp_footer(); ?>
</body>
</html>