<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); ?>

	<section class="sections">
    <div class="container">
		<div class="sections-title">
         <h1>Arr Matey! That treasure can't be found.</h1>
        </div>
        
		<div class="notfound">
            <div class="content-left">
            	<div class="sidebarblock">
                	<ul class="sidebar-nav">
                    <h2>Try these helpful links:</h2>
                    <span class="hide_title">About Sidebar</span>
                    <div class="textwidget">
                    <li><a href="<?php echo get_site_url();?>/visit/">Visit the Museum</a></li>
                    <li><a href="<?php echo get_site_url();?>/exhibits/">See Our Exhibits</a></li>
                    <li><a href="<?php echo get_site_url();?>/parties/">Book Your Party</a></li>
                    <li><a href="<?php echo get_site_url();?>/get-involved/">Get Involved</a></li>
                    <li><a href="<?php echo get_site_url();?>/contact-us/">Contact the Museum</a></li>
                    </div> 
                   </ul>
                </div>
            </div>
            
            <div class="content-right">
            <div class="nfgraphic">
			   <img src="http://staging.bkmtest.com/wowcm/wp-content/themes/wowcm/images/notfound.png" alt="" />
			</div>
            </div>
        </div> 

  </div>
</section><!-- .content-area -->

<section class="subfooter">

    <div class="container">

        <div class="sub-footer-blocks line-top">

            <div class="block">

                <h2><i class="icon-04"></i> book a party </h2>

                <div class="box-pad">

                <?php if(is_active_sidebar( 'book_party' )): 

				dynamic_sidebar('book_party');

				endif; ?>

                </div>

            </div>

            

            <div class="block">

                <h2><i class="icon-noun_4060"></i> become a member </h2>

                <div class="box-pad">

                <?php if(is_active_sidebar( 'become_member' )):

				dynamic_sidebar('become_member');

				endif; ?>

                <a class="btn-orange" href="<?php bloginfo('url'); ?>/become-a-member/">Join Today</a>

                </div>

            </div>

            

            <div class="block">

                <h2><i class="icon-07"></i> donate today </h2>

                <div class="box-pad">

                   <?php if(is_active_sidebar( 'donate_today' )): 
				dynamic_sidebar('donate_today');
				endif; ?>

               

                </div>

            </div>

        </div>

        

    </div>

</section>

<?php get_footer(); ?>
