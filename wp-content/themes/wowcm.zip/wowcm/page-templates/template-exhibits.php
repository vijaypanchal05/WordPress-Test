<?php
/**
 * Template Name: Exhibits Page
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fourteen 1.0
*/
get_header();

   if(get_the_ID()=='20'){$overlayclass = 'overlay';}
	  elseif(get_the_ID()=='382'){$overlayclass = '';}
?>

<section class="innerbillboard">
    <div class="container pr">
        <h1>WOW! <?php the_title();?></h1>
        <div class="dr-line-in"></div>
        <div class="row">
            <div class="col-eight">
                <div class="billboard-left <?php echo $overlayclass;?>">
                    <div class="captions">
<?php if(get_the_ID()=='20'){?>   
<a href="<?php echo do_shortcode('[acf field="featured_link"]');?>" class="btn-pink">Explore More</a>
<?php }?>                 
                <div class="featured-exhibit">
			<?php $field = get_field('featured_exhibit'); // your wysiwyg field data
				  $strip = array('<p>','</p>'); // search for <p>
				  echo str_replace($strip,'',$field);?>                        
				</div>
                    </div>
	   <?php  $banner_img=wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()),"large");?>
                    <img src="<?php echo $banner_img[0];?>" alt="exhibit">
                </div>
            </div>
            <div class="col-four">
                <div class="billboard-right orangebg">
                   <?php if(is_active_sidebar( 'upcoming_exhibits' )):
					dynamic_sidebar('upcoming_exhibits');
					endif; ?>

                </div>
            </div>
        </div>
    </div>
</section>

<section class="sections">
      <div class="container">
          <div class="sections-title">
          <?php echo do_shortcode('[acf field="play_learn_magine"]');?>              
        </div>
        
  <?php if(get_the_ID()=='20'){$typename = 'exhibits';}
	  elseif(get_the_ID()=='382'){$typename = 'events';}
   ?>        
   
        <div class="exhibitsList">
        <?php     
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
query_posts('post_type='.$typename.'&order=ASC&paged=&showposts=50,'.$paged);  $i = 1;
	while(have_posts()) : the_post();?>
        <div class="block">
<h2><i class="<?php echo do_shortcode('[acf field="exhibits_icon"]');?>"></i>&nbsp;<a href="<?php echo do_shortcode('[acf field="exhibits_link"]');?>"><?php the_title();?></a></h2>
                <div class="box-pad">
                   <?php the_content();?>
                    <a class="btn-orange" href="<?php echo do_shortcode('[acf field="exhibits_link"]');?>">Explore</a> 
                </div>
            </div>
			<?php endwhile; wp_reset_query();?>                                      
        </div>
    </div>
</section>
      
  
	<section class="sections">
    <div class="container line-top">
        <div class="content-holder">
        <div class="content-left">
        <div class="sidebarblock">
               <?php if(is_active_sidebar( 'upcoming_events' )):
				dynamic_sidebar('upcoming_events');
				endif; ?>
            </div>
<div class="sidebarblock">
<div class="sidebargraphic"> <img alt="" src="<?php echo get_bloginfo('stylesheet_directory');?>/images/robots.png"> </div>  </div>
</div>
          <div class="content-right">
          <?php
          while ( have_posts() ) : the_post();
		  //echo $post->post_content;
		  the_content();
		  endwhile; ?>
 	      </div>
          
    </div>
  </div>
</section>

  
<?php get_footer();?>