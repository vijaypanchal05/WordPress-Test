<?php

/**

 * Template Name: Get Involved Page

 *

 * @package WordPress

 * @subpackage Twenty_Fifteen

 * @since Twenty Fourteen 1.0

*/

get_header();?>





<section class="smallbillboard">

    <div class="container pr">

        <h1>Get Involved with WOW!</h1>

        <div class="dr-line-in"></div>

        <div class="row">

            <div class="col-eight">

                <div class="billboard-left grapebg">

                    <div class="textcont">

                        <h2>Become a Member</h2>

                <?php if(is_active_sidebar( 'become_member' )):

				dynamic_sidebar('become_member');

				endif; ?>

                        <a href="<?php bloginfo('url'); ?>/become-a-member/" class="btn-green">Explore More</a>

                    </div>

                </div>

            </div>

            <div class="col-four">

                <div class="billboard-right bluebg">

                <div class="textcont">

                    <h2>Help us grow, Donate!</h2>

               <?php if(is_active_sidebar( 'donate_today' )):
				dynamic_sidebar('donate_today');
				endif; ?>
                </div>

                </div>

            </div>

        </div>

    </div>

</section>

      

<section class="sections">

      <div class="container">

          <div class="sections-title">

           <?php echo do_shortcode('[acf field="get_involved"]');?>

        </div>

        <div class="exhibitsList">

        <?php     

$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

query_posts('post_type=get_involved&order=ASC&paged=&showposts=50,'.$paged);  $i = 1;

	while(have_posts()) : the_post();?>        

            <div class="block">

                <h2><i class="<?php echo do_shortcode('[acf field="get_involved_font"]');?>"></i> <?php the_title();?></h2>

                <div class="box-pad">

					<?php the_content();?>

                    <a class="btn-orange" href="<?php echo do_shortcode('[acf field="get_involved_link"]');?>">Explore</a> 

                </div>

            </div>

<?php endwhile; wp_reset_query();?>                                          

            

        </div>

    </div>

</section>

      

<section class="newsletter">

    <div class="container line-top t_center">

        <h2 class="blue">Sign up for our newsletter today!</h2>
        <button type="button" class="btn btn-primary btn-pink" data-toggle="modal" data-target=".bs-example-modal-sm">Sign up Today!</button>
    </div>

</section>

      

<section class="sections">

    <div class="container line-top">

        <div class="content-holder">

        <div class="content-left">

        

        <div class="sidebarblock">

                <?php if(is_active_sidebar( 'upcoming_events' )):

				dynamic_sidebar('upcoming_events');

				endif; ?>

            </div>     

            </div> 

          <div class="content-right">

		  <?php

          while ( have_posts() ) : the_post();
		  the_content();
		  endwhile; ?>

        </div>

    </div>

  </div>

</section>



<?php get_footer();?>

