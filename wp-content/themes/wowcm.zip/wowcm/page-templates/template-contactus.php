<?php

/**

 * Template Name: Contact Us Page

 *

 * @package WordPress

 * @subpackage Twenty_Fifteen

 * @since Twenty Fourteen 1.0

*/

get_header();?>





<section class="innerbillboard">

    <div class="container pr">

        <div class="dr-line-in"></div>

        <h1>Contact us today!</h1>

        <div class="row">

            <div class="col-eight">

                <div class="billboard-left">

 <?php echo do_shortcode('[acf field="google_map"]');?>

                </div>

            </div>

            <div class="col-four">

                <div class="billboard-right bluebg">

				 <?php echo do_shortcode('[acf field="get_in_touch"]');?>                    

                    <div class="contactside">

                    <?php echo do_shortcode('[acf field="contact_location"]');?>

                    </div>    

                    <div class="contactside">

                        <?php echo do_shortcode('[acf field="front_desk"]');?>

                    </div>    

                    <a href="<?php bloginfo('url'); ?>/visit/calendar/" class="btn-orange">View Calendar</a>

                </div>

            </div>

        </div>

    </div>

</section>

      

<section class="sections">

      <div class="container">

          <div class="sections-title">

          <?php

          while ( have_posts() ) : the_post();

		  the_content();

		  endwhile; ?>

         <div class="planeGraphic"><img src="<?php echo get_bloginfo('stylesheet_directory');?>/images/plane.png"></div>

        </div>

        

          <div class="contact-form">

    <?php echo do_shortcode('[contact-form-7 id="86" title="Contact  Us"]');?>

            </div>

    </div>

</section>

<section class="sections">

      <div class="container line-top">

          <div class="sections-title">

			<?php echo do_shortcode('[acf field="more_information"]');?>                    

        </div>

        <div class="contact-info">

        <?php     

$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

query_posts('post_type=contact_info&order=ASC&paged=&showposts=50,'.$paged);  $i = 1;

	while(have_posts()) : the_post();?>

            <div class="block">

                <h4><?php the_title();?></h4>

	              <?php the_content();?>

            </div>

<?php endwhile; wp_reset_query();?>                              

            

              

        </div>

    </div>

</section>







<?php get_footer();?>

