<?php

/**

 * Template Name: Classes Inner Page

 *

 * @package WordPress

 * @subpackage Twenty_Fifteen

 * @since Twenty Fourteen 1.0

*/

get_header();

$banner_img=wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()),"large");?>



<section class="innerbillboard">

    <div class="container pr">

        <h1><?php the_title();?></h1>

        <div class="dr-line-in"></div>

        <div class="row">

            <div class="col-eight">

                <div class="billboard-left">

                <?php if($banner_img[0]!=''){?>

                <img src="<?php echo $banner_img[0];?>" alt="<?php the_title();?>">

                <?php }else{ ?>

                <img src="<?php echo get_bloginfo('stylesheet_directory');?>/images/bubbles_hero.png" alt="<?php the_title();?>">

                    

                 <?php } ?>   

                </div>

            </div>

            <div class="col-four">

                <div class="billboard-right grapebg">

                    <?php echo do_shortcode('[acf field="exhibit_highlights"]');?>

                    <div class="highlights">

<div class="icobox"><img src="<?php echo get_bloginfo('stylesheet_directory');?>/images/exhibit_ico1.png" alt=""><span><?php echo do_shortcode('[acf field="highlights_text1"]');?></span></div>

<div class="icobox"><img src="<?php echo get_bloginfo('stylesheet_directory');?>/images/exhibit_ico2.png" alt=""><span><?php echo do_shortcode('[acf field="exhibit_highlights_text2"]');?></span></div>

<div class="icobox"><img src="<?php echo get_bloginfo('stylesheet_directory');?>/images/exhibit_ico3.png" alt=""><span><?php echo do_shortcode('[acf field="exhibit_highlights_text3"]');?></span></div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>



<section class="sections">

    <div class="container">

        <div class="content-holder">

        <div class="content-left">

            

	   <div class="sidebarblock bdrbtm">

           <ul class="sidebar-nav">

            

            <?php if(is_active_sidebar( 'sidebar_link' )):?>
			 <h2>Programs & Classes</h2>
			<?php dynamic_sidebar('sidebar_link');
				endif; ?> 

           </ul>       

           </div>

        

           <div class="sidebarblock">

                 <ul class="sidebar-cta">

                    <li><h2>book a party</h2>

                        <?php if(is_active_sidebar( 'book_party' )):

						dynamic_sidebar('book_party');

						endif; ?>

                    </li>

                    <li><h2>become a member</h2>

	                    <?php if(is_active_sidebar( 'become_member' )):

						dynamic_sidebar('become_member');

						endif; ?>

                        <a class="btn-orange" href="<?php bloginfo('url'); ?>/become-a-member/">Get Started</a>

                    </li>

                </ul>

           </div>

        </div>

        <div class="content-right">
	      <?php
          while ( have_posts() ) : the_post();
		  the_content();
		  endwhile; ?>
        </div>

            

    </div>

  </div>

</section>

<?php get_footer();?>