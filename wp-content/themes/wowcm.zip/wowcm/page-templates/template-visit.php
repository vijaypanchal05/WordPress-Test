<?php

/**

 * Template Name: Visit Page

 *

 * @package WordPress

 * @subpackage Twenty_Fifteen

 * @since Twenty Fourteen 1.0

*/

get_header();

$banner_img=wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()),"large");?>



<section class="innerbillboard">

    <div class="container pr">

        <h1><?php echo do_shortcode('[acf field="visit_title"]');?></h1>

        <div class="dr-line-in"></div>

        <div class="row">

            <div class="col-eight">

                <div class="billboard-left">

                    <img src="<?php echo $banner_img[0];?>" alt="">

                </div>

            </div>

            <div class="col-four">

                <div class="billboard-right bluebg">

                 <?php echo do_shortcode('[acf field="visit_wow_today"]');?>

                 <?php wp_nav_menu( array('theme_location' => 'visit_menu','menu_class'=> 'visitlink','container'=>''));?>

                </div>

            </div>

        </div>

    </div>

</section>



<section class="about-wcm">

    <div class="container">

        <div class="wcm-inner">

            <div class="wcm-block">

<h3 class="heading">museum hours <img src="<?php echo get_bloginfo('stylesheet_directory');?>/images/hours-ico.png" alt=""></h3>

                <div class="box-pad">

                   <?php if(is_active_sidebar( 'museum_hours_content' )):

				dynamic_sidebar('museum_hours_content');

				endif; ?>

                </div>

            </div>

            

            <div class="wcm-block">

                <h3 class="heading">admission <img src="<?php echo get_bloginfo('stylesheet_directory');?>/images/admission-ico.png" alt=""></h3>

                <div class="box-pad">

                    <?php if(is_active_sidebar( 'admission_content' )):

					dynamic_sidebar('admission_content');

					endif; ?>

                </div>

            </div>

            

            <div class="wcm-block">

<h3 class="heading">location <img src="<?php echo get_bloginfo('stylesheet_directory');?>/images/location-ico.png" alt=""></h3><div class="box-pad">

                  <?php if(is_active_sidebar( 'location_content' )):

				dynamic_sidebar('location_content');

				endif; ?>

                </div>

            </div>

        </div>

        

    </div>

</section>

      

<section class="sections">

    <div class="container">

        <div class="wcm-rsidebar">

        <div class="content-left">

          <?php $content = get_post_field( 'post_content', get_the_ID() );

				$content_parts = get_extended( $content );

				echo $content_parts['main'];?>

        </div>

        

          <div class="content-right">

                <div class="sidebarblock bdrbtm">

                  <?php if(is_active_sidebar( 'whats_nearby' )):

						dynamic_sidebar('whats_nearby');

						endif; ?>

                </div>

            <div class="sidebarblock">

                 <ul class="sidebar-cta">

                    <li><h2>become a member</h2>

                        <?php if(is_active_sidebar( 'become_member' )):

						dynamic_sidebar('become_member');

						endif; ?>

                         <a href="<?php bloginfo('url'); ?>/become-a-member/" class="btn-orange">Join Today</a>

                    </li>

                </ul>

           </div>

                

        </div>

            

    </div>

  </div>

</section>

      

<section class="sections">

      <div class="container line-top">

        <div class="sections-title">

         <?php echo do_shortcode('[acf field="more_ways_to_visit_the_museum"]');?>

        </div>

        <div class="exhibitsList">

            <div class="block">

                <h2><i class="icon-04"></i> book a party </h2>

                <div class="box-pad">

                <?php if(is_active_sidebar( 'book_party' )):

				dynamic_sidebar('book_party');

				endif; ?>
                </div>

            </div>

            <div class="block">

                <h2><i class="icon-noun_2551"></i> schedule a field trip </h2>

                <div class="box-pad">

                 <?php if(is_active_sidebar( 'field_trip' )):

				dynamic_sidebar('field_trip');

				endif; ?>

                </div>

            </div>

            <div class="block">

                <h2><i class="icon-noun_19935"></i> rent a room </h2>

                <div class="box-pad">

                <?php if(is_active_sidebar( 'rent_room' )):

				dynamic_sidebar('rent_room');

				endif; ?>

                </div>

            </div> 

            

        </div>

    </div>

</section>

      

<section class="sections">

    <div class="container line-top">

        <div class="wcm-rsidebar">

        <div class="content-left">

        <?php  echo $content_parts['extended'];?>

        </div>

        

          <div class="content-right">

              <div class="sidebarblock">

               <?php if(is_active_sidebar( 'cleaning_procedures' )):

						dynamic_sidebar('cleaning_procedures');

						endif; ?>

            </div>

        </div>

            

    </div>

  </div>

</section>

<?php get_footer('sub');?>

<?php get_footer();?>

