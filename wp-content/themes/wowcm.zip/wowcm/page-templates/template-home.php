<?php

/**

 * Template Name: Home Page

 *

 * @package WordPress

 * @subpackage Twenty_Fifteen

 * @since Twenty Fourteen 1.0

*/

get_header();?>





<section class="billboard">

    <div class="container">

        <div class="billboard-holder">

        <div class="dr-line"></div>

        <div class="dl-line"></div>

          <?php echo do_shortcode('[acf field="home_banner_content"]');?>

        </div>                 

    </div>

</section>

      

<section class="about-wcm">

    <div class="container">

        <div class="wcm-row">

            <div class="wcm-block">

                <h3 class="heading">museum hours <img src="<?php echo get_bloginfo('stylesheet_directory');?>/images/hours-ico.png" alt="hours"></h3>

                <div class="box-pad">

                 <?php if(is_active_sidebar( 'museum_hours_content' )):

				dynamic_sidebar('museum_hours_content');

				endif; ?>

                </div>

            </div>

            

            <div class="wcm-block">

                <h3 class="heading">admission <img src="<?php echo get_bloginfo('stylesheet_directory');?>/images/admission-ico.png" alt=""></h3>

                <div class="box-pad">

                  <?php if(is_active_sidebar( 'admission_content' )):

					dynamic_sidebar('admission_content');

					endif; ?>

                </div>

            </div>

            

            <div class="wcm-block">

                <h3 class="heading">location <img src="<?php echo get_bloginfo('stylesheet_directory');?>/images/location-ico.png" alt=""></h3>

                <div class="box-pad">

		      <?php if(is_active_sidebar( 'location_content' )):

				dynamic_sidebar('location_content');

				endif; ?>

                </div>

            </div>

        </div>

    </div>

    <div class="roket"><img src="<?php echo get_bloginfo('stylesheet_directory');?>/images/roket.png" alt=""></div>

</section> 

 

<section class="sections">

    <div class="container">

        <div class="content-holder">

        <div class="content-left">

        

        <div class="sidebarblock">

                 <?php if(is_active_sidebar( 'upcoming_events' )):

				dynamic_sidebar('upcoming_events');

				endif; ?>

            </div>     

            

        <div class="sidebarblock">

        <?php if(is_active_sidebar( 'annual_events' )):

				dynamic_sidebar('annual_events');

				endif; ?>

            

        </div>

        

        <div class="sidebarblock">

            <div class="sidebargraphic"> <img src="<?php echo get_bloginfo('stylesheet_directory');?>/images/art_studio.svg" alt=""> </div>    

        </div>



</div>



          <div class="content-right">

             <h1><?php echo do_shortcode('[acf field="home_title"]');?></h1>

            <h2 class="multicolored"><span>Play!</span> <span>Learn!</span> <span>Imagine!</span></h2>

            

            <div class="wcm-content-box">

                <div class="ico icon-06"> </div>

                <div class="rightpart">

                    <h2>inspire learning</h2>

                    <p><?php echo do_shortcode('[acf field="inspire_learning"]');?></p>

                </div> 

            </div>

              

            <div class="wcm-content-box">

                <div class="ico icon-noun_1868"> </div>

                <div class="rightpart">

                    <h2>enhance education</h2>

                    <p><?php echo do_shortcode('[acf field="enhance_education"]');?></p>

                </div> 

            </div>

              

            <div class="wcm-content-box">

                <div class="ico icon-noun_23949"> </div>

                <div class="rightpart">

                    <h2> connect community</h2>

                    <p><?php echo do_shortcode('[acf field="connect_community"]');?></p>
                <a href="<?php echo get_site_url();?>/exhibits" class="btn-endeavour">Explore our Exhibits</a>

<a href="<?php echo get_site_url();?>/about-us" class="btn-orange">Learn more about WOW!</a>

                </div> 

            </div>  

            

        </div>

            

    </div>

  </div>

</section>



<section class="subfooter">

    <div class="container">

        <div class="sub-footer-blocks line-top">

            <div class="block">

                <h2><i class="icon-04"></i> book a party </h2>

                <div class="box-pad">

                <?php if(is_active_sidebar( 'book_party' )): 

				dynamic_sidebar('book_party');

				endif; ?>

                </div>

            </div>

            

            <div class="block">

                <h2><i class="icon-noun_4060"></i> become a member </h2>

                <div class="box-pad">

                <?php if(is_active_sidebar( 'become_member' )):

				dynamic_sidebar('become_member');

				endif; ?>

                <a class="btn-orange" href="<?php bloginfo('url'); ?>/become-a-member/">Join Today</a>

                </div>

            </div>

            

            <div class="block">

                <h2><i class="icon-07"></i> donate today </h2>

                <div class="box-pad">

                   <?php if(is_active_sidebar( 'donate_today' )): 
				dynamic_sidebar('donate_today');
				endif; ?>

               

                </div>

            </div>

        </div>

        

    </div>

</section>









<?php get_footer();?>

